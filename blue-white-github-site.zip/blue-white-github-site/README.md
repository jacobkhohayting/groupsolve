# Blue Horizon Website

A modern white-blue static website built with HTML and CSS for GitHub Pages.

## Pages

- `index.html` — Overview page
- `goals.html` — Goals and mission page
- `about.html` — About page
- `schedule.html` — Schedule page
- `faq-contact.html` — FAQ and contact page
- `styles.css` — Shared styling for all pages

## How to publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload all files from this folder into the repository.
3. Go to **Settings** → **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/root` folder.
6. Save, then wait for GitHub to generate your site link.

## Customization

Search for `Blue Horizon` in the files and replace it with your own project name. Update the schedule, contact email, mission text, and page content as needed.
